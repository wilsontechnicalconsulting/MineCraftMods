package com.wilzacharson.tutorial.proxy;

public class ServerProxy implements CommonProxy {

}
