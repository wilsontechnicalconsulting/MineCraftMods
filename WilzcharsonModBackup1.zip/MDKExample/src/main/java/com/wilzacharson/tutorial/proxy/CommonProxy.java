package com.wilzacharson.tutorial.proxy;

public interface CommonProxy {

}
