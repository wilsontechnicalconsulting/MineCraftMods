package com.wilzacharson.tutorial.proxy;

public class ClientProxy implements CommonProxy{

}
